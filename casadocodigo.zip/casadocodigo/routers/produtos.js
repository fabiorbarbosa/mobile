const produtos = {
    getProduto: (app) => {
        app.get('/produtos', function(request, response) {
            const mysql = require('mysql');
            const connection = mysql.createConnection({
                host: 'localhost',
                user: 'root',
                password: '',
                database: 'casadocodigo',
            });
            connection.query('select * from livros', (error, results) => {
                console.log(error);
                response.render('produtos/lista', {produtos:results});
            });
            connection.end();
        });
    },
    init: (app) => {
        produtos.getProduto(app);
    }
}


module.exports = produtos;