const express = require('express');
const app = express();

app.set('view engine', 'ejs');
app.use('/static', express.static('node_modules/bootstrap/dist'));
require('./routers/produtos').init(app);
app.get('', function(request, response) {
    response.render('home');
});

module.exports = app;
