const app = require('./custom-express');

app.listen(
    3000,
    () => console.log('Servidor iniciado.')
);